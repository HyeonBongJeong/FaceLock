
# Create your models here.
from django.db import models

# Create your models here.
from django.db import models
from account.models import Member


# Create your models here.


class Products(models.Model):
    pro_title = models.CharField(max_length=10, unique=True)
    pro_price = models.IntegerField(default=0)



class Pay(models.Model):
    PAY_CHOICES = [(1,u'결제중'),(2,u'결제완료')]
    member = models.ForeignKey(Member, on_delete=models.CASCADE)
    p_title = models.ForeignKey(Products, on_delete=models.CASCADE)
    p_check = models.CharField(u'결제중', default=1, max_length=10, choices=PAY_CHOICES)

