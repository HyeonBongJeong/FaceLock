
from django.urls import path
from product import views


app_name = 'product'

urlpatterns = [
    path('proList/', views.pro_list, name='proList'),
    path('proDetail/', views.pro_Detail, name='proDetail'),
]