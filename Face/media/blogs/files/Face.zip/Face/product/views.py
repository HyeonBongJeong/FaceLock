from django.shortcuts import render

# Create your views here.
def pro_list(request):
    return render(request, 'product/courses.html')

def pro_Detail(request):
    return render(request, 'product/course-details.html')