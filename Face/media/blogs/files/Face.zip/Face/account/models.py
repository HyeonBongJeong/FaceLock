from django.core.validators import MinLengthValidator
from django.db import models

password_validators = MinLengthValidator(8, "길이가 너무 짧습니다")


class Member(models.Model):
    email = models.EmailField(max_length=100, primary_key=True)
    names = models.CharField(max_length=10)
    password = models.CharField(max_length=20, validators=[password_validators])
    birth = models.DateField()
    phone = models.IntegerField(default=0)

    def __str__(self):
        return self.email
