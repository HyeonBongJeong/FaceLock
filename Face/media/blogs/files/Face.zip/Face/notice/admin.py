
from django.contrib import admin
from notice.models import Notices
# Register your models here.
admin.site.register(Notices)
#admin.site.register(QnA)