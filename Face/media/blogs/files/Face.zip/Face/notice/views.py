from django.shortcuts import render,redirect
from django.urls import reverse
from django.views.generic import ListView, DetailView

from notice.models import *


class NoticesListView(ListView):
    model = Notices

class NoticesDetailView(DetailView):
    model = Notices


